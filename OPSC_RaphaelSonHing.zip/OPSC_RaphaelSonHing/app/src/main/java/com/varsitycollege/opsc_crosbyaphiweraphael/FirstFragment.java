package com.varsitycollege.opsc_crosbyaphiweraphael;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.varsitycollege.opsc_crosbyaphiweraphael.databinding.FragmentFirstBinding;


// This attempt didn't turn out well, may come back to later but better to abadon it.
public class FirstFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    //ViewBinding
    private FragmentCacheAddBinding binding;
    //Progress Dialog
    ProgressDialog progressDialog;
    //StaticFields object to access static fields
    private StaticFields placeholder = new StaticFields();

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;



    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment fragment_addcache.
     */
    // TODO: Rename and change types and number of parameters
    public static CacheAddFragment newInstance(String param1, String param2) {
        CacheAddFragment fragment = new CacheAddFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    //Cache Form Variables
    private String CacheDifficulty = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //Our own code
        binding = FragmentCacheAddBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        //Instantiate ProgressDialog
        progressDialog = new ProgressDialog(getContext());
        progressDialog.setTitle("Please wait...");
        progressDialog.setCanceledOnTouchOutside(false);


        };

        return view;
    }

    private void CacheToFirebase() {

        progressDialog.show();

        //Get ID for Collection
        String id = "" + System.currentTimeMillis();

        //Create HashMap to push to FireBase
        HashMap<String, Object> hashMap = new HashMap<>();


        //Get Reference
        DatabaseReference refCaches = FirebaseDatabase.getInstance().getReference("caches");
        //Set firebase id and add hashmap
        refCaches.child("" + CacheToAdd.getId())
                .setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(getContext(), "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }





        SetData();
    }


}