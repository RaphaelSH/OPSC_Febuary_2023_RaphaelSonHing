package com.varsitycollege.opsc_crosbyaphiweraphael;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import android.app.ProgressDialog;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import android.content.Intent;
import com.google.android.gms.tasks.OnFailureListener;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;





import java.util.HashMap;



public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;
    //Firebase Authentication
    private FirebaseAuth FireAuth;
    //Variable to use Progress Dialog
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //Initialise Firebase Authentication
        FireAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Standby");
        progressDialog.setCanceledOnTouchOutside(false);

        binding.btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateData();
            }
        });

        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), WelcomeActivity.class);
                startActivity(i);
            }
        });
    }

    String name = "";
    String email = "";
    String passwd = "";
    String confirmPasswd = "";
    String textResponse = "You have not entered correct information. Please reenter data.";
    private void ValidateData() {
        name = binding.edtName.getText().toString().trim();
        email = binding.edtEmail.getText().toString().trim();
        passwd = binding.edtPassword.getText().toString().trim();
        confirmPasswd = binding.edtConfirmPassword.getText().toString().trim();



        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, textResponse, Toast.LENGTH_SHORT).show();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, textResponse, Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(passwd)) {
            Toast.makeText(this, textResponse, Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(confirmPasswd)) {
            Toast.makeText(this, textResponse, Toast.LENGTH_SHORT).show();
        } else if (!passwd.equals(confirmPasswd)) {
            Toast.makeText(this, textResponse, Toast.LENGTH_SHORT).show();
        } else {
            CreateUserAccount();
        }
    }

    private void CreateUserAccount() {
        //Stall user
        progressDialog.show();

        //Create user on Firebase
        FireAuth.createUserWithEmailAndPassword(email, passwd)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        UpdateUserInfo();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(RegisterActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void UpdateUserInfo() {
        progressDialog.setMessage("Standby");

        String u_id = FireAuth.getUid();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("uid", u_id);
        hashMap.put("email", email);
        hashMap.put("name", name);

        DatabaseReference refUsers = FirebaseDatabase.getInstance().getReference("users");

        refUsers.child(u_id)
                .setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                        Toast.makeText(RegisterActivity.this, "Profile ceated", Toast.LENGTH_SHORT).show();

                        Intent i = new Intent(RegisterActivity.this, MapsActivity.class);
                        startActivity(i);

                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(RegisterActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }
}