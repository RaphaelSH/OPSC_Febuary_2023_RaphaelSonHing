create table location
(
	locID varchar(10) not null primary key,
	locationName varchar(20) not null,
	ZipCode varchar(5) not null
);