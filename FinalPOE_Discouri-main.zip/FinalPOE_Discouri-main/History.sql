create table history
(
	userID varchar(10) not null primary key,
	bikeHistory varchar(20) not null,
	walkHistory varchar(20) not null
);